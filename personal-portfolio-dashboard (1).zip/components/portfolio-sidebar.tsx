"use client"

import { LayoutDashboard, Wallet, History, Settings } from "lucide-react"
import { cn } from "@/lib/utils"

interface PortfolioSidebarProps {
  activeNav: string
  setActiveNav: (nav: string) => void
}

const navItems = [
  { id: "dashboard", label: "Dasbor", icon: LayoutDashboard },
  { id: "assets", label: "Aset", icon: Wallet },
  { id: "history", label: "Riwayat", icon: History },
  { id: "settings", label: "Pengaturan", icon: Settings },
]

export function PortfolioSidebar({ activeNav, setActiveNav }: PortfolioSidebarProps) {
  return (
    <aside className="w-64 border-r border-sidebar-border bg-sidebar">
      <div className="p-6">
        <h2 className="text-2xl font-bold text-sidebar-foreground">PortfolioTracker</h2>
        <p className="text-sm text-muted-foreground mt-1">Pelacak Investasi</p>
      </div>

      <nav className="px-3 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon
          const isActive = activeNav === item.id

          return (
            <button
              key={item.id}
              onClick={() => setActiveNav(item.id)}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                isActive
                  ? "bg-sidebar-accent text-sidebar-accent-foreground"
                  : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground",
              )}
            >
              <Icon className="h-5 w-5" />
              {item.label}
            </button>
          )
        })}
      </nav>

      <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-sidebar-accent flex items-center justify-center text-sidebar-accent-foreground font-semibold">
            JD
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium text-sidebar-foreground">John Doe</p>
            <p className="text-xs text-muted-foreground">john@email.com</p>
          </div>
        </div>
      </div>
    </aside>
  )
}
