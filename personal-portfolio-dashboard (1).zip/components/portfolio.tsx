"use client"

import { useState } from "react"
import { PortfolioHeader } from "./portfolio-header"
import { PortfolioSidebar } from "./portfolio-sidebar"
import { PortfolioChart } from "./portfolio-chart"
import { AssetsTable } from "./assets-table"
import { AddAssetModal } from "./add-asset-modal"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"

export function Portfolio() {
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [activeNav, setActiveNav] = useState("dashboard")

  return (
    <div className="flex h-screen overflow-hidden">
      <PortfolioSidebar activeNav={activeNav} setActiveNav={setActiveNav} />

      <div className="flex-1 flex flex-col overflow-hidden">
        <PortfolioHeader />

        <main className="flex-1 overflow-y-auto p-6 lg:p-8">
          <div className="max-w-7xl mx-auto space-y-6">
            <PortfolioChart />

            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-semibold text-foreground">Aset Saat Ini</h2>
                <p className="text-sm text-muted-foreground mt-1">Kelola dan pantau portfolio investasi Anda</p>
              </div>
              <Button
                onClick={() => setIsModalOpen(true)}
                className="bg-primary text-primary-foreground hover:bg-primary/90"
              >
                <Plus className="h-4 w-4 mr-2" />
                Tambah Aset Baru
              </Button>
            </div>

            <AssetsTable />
          </div>
        </main>
      </div>

      <AddAssetModal open={isModalOpen} onOpenChange={setIsModalOpen} />
    </div>
  )
}
