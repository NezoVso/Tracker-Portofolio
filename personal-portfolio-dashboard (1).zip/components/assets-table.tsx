import { Card } from "@/components/ui/card"
import { TrendingUp, TrendingDown } from "lucide-react"
import { cn } from "@/lib/utils"

const assets = [
  {
    id: 1,
    name: "Bitcoin",
    category: "Cryptocurrency",
    amount: "2.5 BTC",
    value: 85000000,
    change: 15.2,
    isPositive: true,
  },
  {
    id: 2,
    name: "Saham BBCA",
    category: "Saham",
    amount: "5000 lembar",
    value: 48750000,
    change: 8.5,
    isPositive: true,
  },
  {
    id: 3,
    name: "Emas",
    category: "Logam Mulia",
    amount: "100 gram",
    value: 95000000,
    change: 3.2,
    isPositive: true,
  },
  {
    id: 4,
    name: "Reksadana Pendapatan Tetap",
    category: "Reksadana",
    amount: "20000 unit",
    value: 20000000,
    change: -2.1,
    isPositive: false,
  },
]

export function AssetsTable() {
  return (
    <Card className="border border-border overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="border-b border-border bg-muted/30">
            <tr>
              <th className="text-left py-4 px-6 text-sm font-semibold text-foreground">Nama Aset</th>
              <th className="text-left py-4 px-6 text-sm font-semibold text-foreground">Kategori</th>
              <th className="text-left py-4 px-6 text-sm font-semibold text-foreground">Jumlah</th>
              <th className="text-right py-4 px-6 text-sm font-semibold text-foreground">Nilai Saat Ini</th>
              <th className="text-right py-4 px-6 text-sm font-semibold text-foreground">Laba/Rugi</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {assets.map((asset) => (
              <tr key={asset.id} className="hover:bg-muted/20 transition-colors">
                <td className="py-4 px-6">
                  <span className="font-medium text-foreground">{asset.name}</span>
                </td>
                <td className="py-4 px-6">
                  <span className="text-sm text-muted-foreground">{asset.category}</span>
                </td>
                <td className="py-4 px-6">
                  <span className="text-sm text-foreground">{asset.amount}</span>
                </td>
                <td className="py-4 px-6 text-right">
                  <span className="font-semibold text-foreground">Rp {asset.value.toLocaleString("id-ID")}</span>
                </td>
                <td className="py-4 px-6 text-right">
                  <div
                    className={cn(
                      "inline-flex items-center gap-1 font-medium",
                      asset.isPositive ? "text-primary" : "text-destructive",
                    )}
                  >
                    {asset.isPositive ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
                    <span>
                      {asset.isPositive ? "+" : ""}
                      {asset.change}%
                    </span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  )
}
