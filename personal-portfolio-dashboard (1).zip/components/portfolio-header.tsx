import { TrendingUp } from "lucide-react"

export function PortfolioHeader() {
  return (
    <header className="border-b border-border bg-card">
      <div className="px-6 lg:px-8 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Rp 248,750,000</h1>
            <div className="flex items-center gap-2 mt-1">
              <div className="flex items-center gap-1 text-primary">
                <TrendingUp className="h-4 w-4" />
                <span className="text-sm font-medium">+12.45%</span>
              </div>
              <span className="text-sm text-muted-foreground">hari ini</span>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-6">
            <div>
              <p className="text-xs text-muted-foreground">Total Investasi</p>
              <p className="text-lg font-semibold text-foreground">Rp 220,000,000</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Total Keuntungan</p>
              <p className="text-lg font-semibold text-primary">+Rp 28,750,000</p>
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}
