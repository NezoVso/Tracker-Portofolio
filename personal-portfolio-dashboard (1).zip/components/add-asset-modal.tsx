"use client"

import type React from "react"

import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface AddAssetModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function AddAssetModal({ open, onOpenChange }: AddAssetModalProps) {
  const [formData, setFormData] = useState({
    name: "",
    category: "",
    amount: "",
    value: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Asset data:", formData)
    onOpenChange(false)
    setFormData({ name: "", category: "", amount: "", value: "" })
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] bg-popover border-border">
        <DialogHeader>
          <DialogTitle className="text-foreground">Tambah Aset Baru</DialogTitle>
          <DialogDescription className="text-muted-foreground">
            Masukkan detail aset investasi baru Anda
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit}>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name" className="text-foreground">
                Nama Aset
              </Label>
              <Input
                id="name"
                placeholder="Contoh: Bitcoin, Saham BBCA"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-input border-border text-foreground"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="category" className="text-foreground">
                Kategori
              </Label>
              <Select
                value={formData.category}
                onValueChange={(value) => setFormData({ ...formData, category: value })}
                required
              >
                <SelectTrigger className="bg-input border-border text-foreground">
                  <SelectValue placeholder="Pilih kategori" />
                </SelectTrigger>
                <SelectContent className="bg-popover border-border">
                  <SelectItem value="crypto">Cryptocurrency</SelectItem>
                  <SelectItem value="saham">Saham</SelectItem>
                  <SelectItem value="emas">Logam Mulia</SelectItem>
                  <SelectItem value="reksadana">Reksadana</SelectItem>
                  <SelectItem value="properti">Properti</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="amount" className="text-foreground">
                Jumlah
              </Label>
              <Input
                id="amount"
                placeholder="Contoh: 2.5 BTC, 1000 lembar"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                className="bg-input border-border text-foreground"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="value" className="text-foreground">
                Nilai Saat Ini (Rp)
              </Label>
              <Input
                id="value"
                type="number"
                placeholder="Contoh: 85000000"
                value={formData.value}
                onChange={(e) => setFormData({ ...formData, value: e.target.value })}
                className="bg-input border-border text-foreground"
                required
              />
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="border-border">
              Batal
            </Button>
            <Button type="submit" className="bg-primary text-primary-foreground hover:bg-primary/90">
              Tambah Aset
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
