"use client"

import { Card } from "@/components/ui/card"
import { Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"

const data = [
  { date: "Jan", value: 180000000 },
  { date: "Feb", value: 195000000 },
  { date: "Mar", value: 188000000 },
  { date: "Apr", value: 205000000 },
  { date: "May", value: 218000000 },
  { date: "Jun", value: 225000000 },
  { date: "Jul", value: 232000000 },
  { date: "Aug", value: 240000000 },
  { date: "Sep", value: 248750000 },
]

export function PortfolioChart() {
  return (
    <Card className="p-6 bg-card border-border">
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-foreground">Kinerja Portfolio</h3>
        <p className="text-sm text-muted-foreground mt-1">Grafik pertumbuhan nilai investasi Anda</p>
      </div>

      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={data}>
          <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
          <YAxis
            stroke="hsl(var(--muted-foreground))"
            fontSize={12}
            tickLine={false}
            axisLine={false}
            tickFormatter={(value) => `${(value / 1000000).toFixed(0)}M`}
          />
          <Tooltip
            content={({ active, payload }) => {
              if (active && payload && payload.length) {
                return (
                  <div className="bg-popover border border-border rounded-lg p-3 shadow-lg">
                    <p className="text-sm text-muted-foreground">{payload[0].payload.date}</p>
                    <p className="text-lg font-semibold text-primary">
                      Rp {(payload[0].value as number).toLocaleString("id-ID")}
                    </p>
                  </div>
                )
              }
              return null
            }}
          />
          <Line type="monotone" dataKey="value" stroke="hsl(var(--primary))" strokeWidth={2.5} dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </Card>
  )
}
